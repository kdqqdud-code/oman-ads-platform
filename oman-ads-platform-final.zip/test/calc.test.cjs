const {est,actual}=require("../public/calc.js");let ok=true;const t=(n,c)=>{console.log((c?"PASS ":"FAIL ")+n);if(!c)ok=false};
let e=est({budget:1,cpm:2,ctr:1,freq:2,waRate:20});
t("ظهور=500 عند $1 وCPM $2",Math.round(e.imp)==500);t("الوصول=ظهور/تكرار",Math.round(e.reach)==250);t("نقرات=5",Math.round(e.clicks)==5);t("CPC=0.2",Math.abs(e.cpc-0.2)<1e-9);t("نقرات واتساب=1",Math.abs(e.wa-1)<1e-9);t("ميزانية $1 لا تكفي 1000 ظهور عند CPM $2",e.ok1000===false);
t("CPM=1 يكفي 1000 ظهور بدولار",est({budget:1,cpm:1,ctr:1,freq:1,waRate:20}).ok1000===true);
t("مدخلات ناقصة ترجع null",est({budget:0,cpm:2})===null);
const a=actual({spend:5,imp:2500,clk:50,wa:10});t("CPM فعلي=2",Math.abs(a.cpm-2)<1e-9);t("CTR=2%",Math.abs(a.ctr-2)<1e-9);t("بدون بيانات لا قسمة على صفر",actual({spend:1,imp:0,clk:0,wa:0}).cpm===null);
process.exit(ok?0:1)
