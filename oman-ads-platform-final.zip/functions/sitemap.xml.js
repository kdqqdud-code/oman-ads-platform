export async function onRequestGet({request:r,env:e}){
const o=new URL(r.url).origin,q=(await e.DB.prepare("SELECT id,updated FROM ads WHERE status='published'").all()).results;
return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${o}/</loc></url>${q.map(a=>`<url><loc>${o}/a/${a.id}</loc><lastmod>${new Date(a.updated).toISOString().slice(0,10)}</lastmod></url>`).join("")}</urlset>`,{headers:{"content-type":"application/xml"}})}
