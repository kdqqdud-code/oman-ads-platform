const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json","cache-control":"no-store"}});
const auth=(r,e)=>{const t=(r.headers.get("authorization")||"").replace("Bearer ",""),a=e.ADMIN_TOKEN||"";if(a.length<16||t.length!==a.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=t.charCodeAt(i)^a.charCodeAt(i);return d===0};
const CITY=["مسقط","صلالة","صحار","نزوى","صور","الباطنة","الداخلية","ظفار","كل عُمان"],COND=["جديد","مستعمل بحالة ممتازة","مستعمل"],ST=["draft","published","sold"];
const CAT=["هواتف","لابتوبات","أجهزة لوحية","شاشات وتلفزيونات","ألعاب وأجهزة ألعاب","ملحقات","أخرى"],F=new Map();
const magic=(m,d)=>{try{const h=atob(d.slice(0,16));return m=="image/jpeg"?h.startsWith("\xff\xd8\xff"):m=="image/png"?h.startsWith("\x89PNG"):h.startsWith("RIFF")&&h.slice(8,12)=="WEBP"}catch(x){return false}};
const uid=()=>crypto.randomUUID().replace(/-/g,"").slice(0,12);
function clean(b){let wa=String(b.wa||"").replace(/\D/g,"");if(wa.length==8)wa="968"+wa;const p=Number(b.price);
const o={title:String(b.title||"").trim(),price:p,city:b.city,cat:b.cat||"أخرى",cond:b.cond,descr:String(b.descr||"").trim(),wa,status:b.status||"draft"};
if(o.title.length<3||o.title.length>120)return"العنوان 3-120 حرفًا";if(!(p>=0&&p<=1e6))return"سعر غير صالح";if(!CITY.includes(o.city))return"مدينة غير صالحة";if(!CAT.includes(o.cat))return"تصنيف غير صالح";if(!COND.includes(o.cond))return"حالة غير صالحة";
if(o.descr.length<10||o.descr.length>4000)return"الوصف 10-4000 حرف";if(!/^968\d{8}$/.test(wa))return"رقم واتساب عماني غير صحيح";if(!ST.includes(o.status))return"حالة نشر غير صالحة";return o}
export async function onRequest({request:r,env:e,params:pa}){
const s=pa.path||[],m=r.method,db=e.DB;
try{
if(s[0]=="pub"&&m=="GET"){const u=new URL(r.url),c=u.searchParams.get("cat"),q=(u.searchParams.get("q")||"").slice(0,60);let w="status='published'",a=[];if(c&&CAT.includes(c)){w+=" AND cat=?";a.push(c)}if(q){w+=" AND (title LIKE ? OR descr LIKE ?)";a.push("%"+q+"%","%"+q+"%")}
const x=await db.prepare("SELECT a.id,a.title,a.price,a.city,a.cat,a.cond,(SELECT id FROM images WHERE ad_id=a.id ORDER BY pos LIMIT 1) img FROM ads a WHERE "+w+" ORDER BY updated DESC LIMIT 100").bind(...a).all();return J(x.results)}
const ip=r.headers.get("cf-connecting-ip")||"x",f=F.get(ip);if(f&&f.n>=10&&Date.now()-f.t<6e5)return J({error:"محاولات كثيرة، انتظر 10 دقائق"},429);
if(!auth(r,e)){F.set(ip,{n:(f&&Date.now()-f.t<6e5?f.n:0)+1,t:Date.now()});return J({error:"غير مصرح"},401)}F.delete(ip);
if(s[0]=="ads"&&!s[1]&&m=="GET"){const q=await db.prepare("SELECT a.*,(SELECT COUNT(*) FROM events WHERE ad_id=a.id AND type='view') views,(SELECT COUNT(*) FROM events WHERE ad_id=a.id AND type='wa') wa_clicks,(SELECT group_concat(id) FROM (SELECT id FROM images WHERE ad_id=a.id ORDER BY pos)) imgs FROM ads a ORDER BY updated DESC").all();return J(q.results)}
if(s[0]=="ads"&&!s[1]&&m=="POST"){const o=clean(await r.json());if(typeof o=="string")return J({error:o},400);const id=uid(),t=Date.now();
await db.prepare("INSERT INTO ads(id,title,price,city,cat,cond,descr,wa,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)").bind(id,o.title,o.price,o.city,o.cat,o.cond,o.descr,o.wa,o.status,t,t).run();return J({id})}
if(s[0]=="ads"&&s[1]&&!s[2]&&m=="PUT"){const o=clean(await r.json());if(typeof o=="string")return J({error:o},400);
const u=await db.prepare("UPDATE ads SET title=?,price=?,city=?,cat=?,cond=?,descr=?,wa=?,status=?,updated=? WHERE id=?").bind(o.title,o.price,o.city,o.cat,o.cond,o.descr,o.wa,o.status,Date.now(),s[1]).run();return u.meta.changes?J({ok:1}):J({error:"الإعلان غير موجود"},404)}
if(s[0]=="ads"&&s[1]&&!s[2]&&m=="DELETE"){await db.batch([db.prepare("DELETE FROM images WHERE ad_id=?").bind(s[1]),db.prepare("DELETE FROM events WHERE ad_id=?").bind(s[1]),db.prepare("DELETE FROM ads WHERE id=?").bind(s[1])]);return J({ok:1})}
if(s[0]=="ads"&&s[2]=="images"&&m=="POST"){const b=await r.json();if(!["image/jpeg","image/png","image/webp"].includes(b.mime)||typeof b.data!="string"||b.data.length>1400000||!/^[A-Za-z0-9+/=]+$/.test(b.data)||!magic(b.mime,b.data))return J({error:"صورة غير صالحة أو كبيرة"},400);
if(!await db.prepare("SELECT id FROM ads WHERE id=?").bind(s[1]).first())return J({error:"الإعلان غير موجود"},404);const n=await db.prepare("SELECT COUNT(*) c FROM images WHERE ad_id=?").bind(s[1]).first();if(n.c>=6)return J({error:"الحد 6 صور"},400);const id=uid();
await db.prepare("INSERT INTO images(id,ad_id,mime,data,pos) VALUES(?,?,?,?,?)").bind(id,s[1],b.mime,b.data,n.c).run();return J({id})}
if(s[0]=="images"&&s[1]&&m=="DELETE"){await db.prepare("DELETE FROM images WHERE id=?").bind(s[1]).run();return J({ok:1})}
if(s[0]=="backup"&&m=="GET"){const[a,i,v]=await Promise.all(["ads","images","events"].map(t=>db.prepare("SELECT * FROM "+t).all()));return J({ads:a.results,images:i.results,events:v.results})}
if(s[0]=="restore"&&m=="POST"){const d=await r.json();if(!Array.isArray(d.ads)||!Array.isArray(d.images))return J({error:"ملف غير صالح"},400);
const st=[];for(const a of d.ads)st.push(db.prepare("INSERT OR REPLACE INTO ads(id,title,price,city,cat,cond,descr,wa,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)").bind(a.id,a.title,a.price,a.city,a.cat||"أخرى",a.cond,a.descr,a.wa,a.status,a.created,a.updated));
for(const i of d.images)st.push(db.prepare("INSERT OR REPLACE INTO images(id,ad_id,mime,data,pos) VALUES(?,?,?,?,?)").bind(i.id,i.ad_id,i.mime,i.data,i.pos));
for(let k=0;k<st.length;k+=50)await db.batch(st.slice(k,k+50));return J({ok:st.length})}
return J({error:"غير موجود"},404)}catch(x){return J({error:"خطأ في الخادم"},500)}}
