export async function onRequest({request:r,next}){const res=await next(),u=new URL(r.url),h=new Headers(res.headers);
h.set("x-content-type-options","nosniff");h.set("referrer-policy","strict-origin-when-cross-origin");h.set("x-frame-options","DENY");
if(/^\/(admin|calc|api\/|go\/)/.test(u.pathname))h.set("x-robots-tag","noindex, nofollow");
if(/^\/(admin|api\/)/.test(u.pathname))h.set("cache-control","no-store");
return new Response(res.body,{status:res.status,statusText:res.statusText,headers:h})}
