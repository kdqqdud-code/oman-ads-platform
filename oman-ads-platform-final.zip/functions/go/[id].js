export async function onRequestGet({request:r,env:e,params:p}){
const a=await e.DB.prepare("SELECT title,wa FROM ads WHERE id=? AND status='published'").bind(p.id).first();
if(!a)return new Response("غير موجود",{status:404});
const u=new URL(r.url);
if(!/bot|crawl|spider|slurp|preview/i.test(r.headers.get("user-agent")||""))await e.DB.prepare("INSERT INTO events(ad_id,type,src,ts) VALUES(?,?,?,?)").bind(p.id,"wa",(u.searchParams.get("src")||"direct").slice(0,40),Date.now()).run();
return Response.redirect(`https://wa.me/${a.wa}?text=${encodeURIComponent("مرحبًا، أستفسر عن: "+a.title+" — "+u.origin+"/a/"+p.id)}`,302)}
