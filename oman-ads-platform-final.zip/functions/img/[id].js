export async function onRequestGet({env:e,params:p}){
const i=await e.DB.prepare("SELECT mime,data FROM images WHERE id=?").bind(p.id).first();
if(!i)return new Response("",{status:404});
return new Response(Uint8Array.from(atob(i.data),c=>c.charCodeAt(0)),{headers:{"content-type":i.mime,"cache-control":"public,max-age=86400","x-content-type-options":"nosniff"}})}
