function est(o){const b=+o.budget,cpm=+o.cpm,ctr=+o.ctr/100,f=Math.max(1,+o.freq),w=+o.waRate/100;
if(!(b>0&&cpm>0))return null;const imp=b/cpm*1000,reach=imp/f,clicks=imp*ctr,wa=clicks*w;
return{imp,reach,clicks,wa,cpc:clicks?b/clicks:null,cpwa:wa?b/wa:null,budgetFor1000:cpm,ok1000:cpm<=b}}
function actual(o){const b=+o.spend,i=+o.imp,c=+o.clk,w=+o.wa;return{cpm:i?b/i*1000:null,cpc:c?b/c:null,ctr:i?c/i*100:null,cpwa:w?b/w:null}}
if(typeof module!="undefined")module.exports={est,actual};
