# منصة إعلانات الأجهزة الإلكترونية – عُمان
## النشر (من الجوال)
1. GitHub: أنشئ مستودعًا خاصًا (Private) وارفع محتوى المجلد (لا ترفع أي توكن).
2. Cloudflare → Workers & Pages → Create → Pages → Connect to Git. Build command: فارغ. Output directory: public.
3. Storage & Databases → D1 → Create باسم oman-ads → Console → الصق schema.sql ونفّذه.
4. Pages project → Settings → Bindings → D1 database: Variable name = DB.
5. Settings → Variables and Secrets → Secret باسم ADMIN_TOKEN (16 حرفًا فأكثر، ولا تشاركه).
6. أعد النشر (Retry deployment). ثم افتح /admin.html.
## بعد النشر
Search Console: تحقق الملكية ثم أرسل /sitemap.xml. Merchant Center: أضف /feed.xml (غير مختبر مع Google).
## التحديث والاستعادة
عدّل الملفات في GitHub فيُنشر تلقائيًا. النسخ الاحتياطي من الإدارة (يحوي إعلانات وصورًا وأحداثًا، بلا أسرار). خزّنه بعيدًا عن المستودع العام.
## الاختبار المحلي
node test/run.mjs ثم node test/calc.test.cjs (Node 22+)
